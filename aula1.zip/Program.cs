﻿using CAS;
using System.Numerics;

Expressao a = 10;
Expressao b = "b";

Expressao soma = a + b;
Expressao c = 50;

Console.WriteLine(a+c);


