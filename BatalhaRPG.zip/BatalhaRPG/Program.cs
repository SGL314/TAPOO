﻿using System;
using System.Diagnostics;
using BatalhaRPG;
using System.Numerics;

namespace RPG;

class Program
{
    static void Main()
    {
        const int tamanhoExercito = 1_000_000; // Meio milhão de personagens!

        Personagem[] atacantes = SimuladorCombate.GerarExercito(tamanhoExercito, "atacante");
        Personagem[] defensores = SimuladorCombate.GerarExercito(tamanhoExercito, "defensor");

        Console.WriteLine($"Exércitos: {tamanhoExercito:N0} vs {tamanhoExercito:N0}");

        Stopwatch cronometro = Stopwatch.StartNew();
        int danoTotalRodada = SimuladorCombate.SimularRodadaCombate(atacantes, defensores);
        cronometro.Stop();

        Console.WriteLine($"Dano total causado: {danoTotalRodada:N0}");
        Console.WriteLine($"Tempo sem SIMD: {cronometro.ElapsedMilliseconds}ms");
        Console.WriteLine($"DPS (danos por segundo): {danoTotalRodada * 1000 / Math.Max(1, cronometro.ElapsedMilliseconds):N0}");


        var exercitoAtacantesSIMD = new ExercitoSIMD(atacantes);
        var exercitoDefensoresSIMD = new ExercitoSIMD(defensores);

        cronometro = Stopwatch.StartNew();
        int danoTotalRodadaSIMD = SimuladorCombate.SimularRodadaCombate(exercitoAtacantesSIMD, exercitoDefensoresSIMD);
        cronometro.Stop();

        Console.WriteLine($"Dano total causado: {danoTotalRodadaSIMD:N0}");
        Console.WriteLine($"Tempo com SIMD: {cronometro.ElapsedMilliseconds}ms");
        Console.WriteLine($"DPS (danos por segundo): {danoTotalRodadaSIMD * 1000 / Math.Max(1, cronometro.ElapsedMilliseconds):N0}");
    }
}
