﻿using System;
using System.Net.Sockets;
using System.Text;


const string host = "127.0.0.1";
const int porta = 9000;
using var cliente = new TcpClient();
await cliente.ConnectAsync(host, porta);
using var stream = cliente.GetStream();

bool continuar = true;

var t1 = Receber();
var t2 = Enviar();

await Task.WhenAll(t1, t2);
Console.WriteLine("Fim");


async Task Enviar()
{
    while(continuar)
    {
        var msg = Console.ReadLine();
        if (!string.IsNullOrEmpty(msg))
            await EnviaMensagem(msg);

        if(msg == "sair")
        {
            continuar = false;
            break;
        }
    }
}

async Task Receber()
{
    while(continuar)
    {
        var msg = await RecebeMensagem();
        if(msg == "sair")
        {
            continuar = false;
            break;
        }
        if(!string.IsNullOrEmpty(msg)) 
            Console.WriteLine($"Servidor: {msg}");
    }
}

async Task EnviaMensagem(string mensagem)
{
    var dados = Encoding.UTF8.GetBytes(mensagem);
    await stream.WriteAsync(dados, 0, dados.Length);
}

async Task<string> RecebeMensagem()
{
    var buffer = new byte[1024];
    int lidos = await stream.ReadAsync(buffer, 0, buffer.Length);
    return Encoding.UTF8.GetString(buffer, 0, lidos);
}




	
